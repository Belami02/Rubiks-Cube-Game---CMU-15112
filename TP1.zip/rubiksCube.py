from cmu_graphics import *
import random


#################################################
# Term Project: Rubik's cube
#################################################
def gameDimensions():
    # each face of the Rubik's cube is 3x3
    faceSize = 3
    # there are 6 faces in a Rubik's cube
    faces = 6
    cellSize = 30
    margin = 80
    # the cube is spread in a cross pattern with a maximum width of 4 faces and height of 3
    cols = faceSize * 4
    rows = faceSize * 3
    return rows, cols, cellSize, margin


def getFaceStart(faceIndex):
    # mapping assumes the following layout for the unfolded cube:
    #   0
    # 1 2 3 4
    #   5
    # where '0' is the top, '1' is the left,'2' is the front face,
    # '3' is the right, '4' is the back, '5' is the bottom

    # calculate the starting row and column for each face
    if faceIndex == 0:  # Top face
        return 0, 3
    elif faceIndex == 1:  # Left face
        return 3, 0
    elif faceIndex == 2:  # Front face
        return 3, 3
    elif faceIndex == 3:  # Right face
        return 3, 6
    elif faceIndex == 4:  # Back face
        return 3, 9
    elif faceIndex == 5:  # Bottom face
        return 6, 3


def onAppStart(app):
    app.rows, app.cols, app.cellSize, app.margin = gameDimensions()
    app.emptyColor = "white"
    app.boardWidth = app.cols * app.cellSize
    app.boardHeight = app.rows * app.cellSize
    app.color = "white"
    app.cellBorderWidth = 1
    app.isSolving = False
    app.movesLog = []  # keep the moves made
    # each face of the Rubik's cube with different colors
    app.board = [[app.emptyColor for col in range(app.cols)] for row in range(app.rows)]
    # faces
    app.frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    app.topFace = [app.board[r][3:6] for r in range(0, 3)]
    rightFace = [app.board[r][6:9] for r in range(3, 6)]
    # colors for each face
    colors = ["red", "green", "blue", "yellow", "orange", "white"]
    # set the colors for each face on the board
    for i in range(6):
        faceRow, faceCol = getFaceStart(i)
        for row in range(faceRow, faceRow + 3):
            for col in range(faceCol, faceCol + 3):
                app.board[row][col] = colors[i]


def drawBackground(app):
    drawRect(0, 0, app.width, app.height, fill="white")


def drawBorder(app):
    drawRect(
        app.margin - 5,
        app.margin - 5,
        app.boardWidth + 10,
        app.boardHeight + 10,
        fill="black",
    )


def playRubiks():
    rows, cols, cellSize, margin = gameDimensions()
    width = cols * cellSize + 2 * margin
    height = rows * cellSize + 2 * margin
    runApp(width=width, height=height)


def drawRubiksCube(app):
    # the 2d Rubik's cube layout
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)


def drawCell(app, row, col, color=None):
    # getting the top-left corner coordinates of the cell
    cellLeft, cellTop = getCellLeftTop(app, row, col)

    # if no color is provided,
    # use the color from the corresponding position in 'app.board'
    if color is None:
        color = app.board[row][col]

    # Determine if the current cell is part of a face
    if isPartOfFace(app, row, col):
        borderWidth = app.cellBorderWidth
    else:
        borderWidth = 0  # No border if the cell is not part of a face

    drawRect(
        cellLeft,
        cellTop,
        app.cellSize,
        app.cellSize,
        fill=color,
        border="black",
        borderWidth=borderWidth,
    )


def isPartOfFace(app, row, col):
    # Top face is from rows 0 to 2 and columns 3 to 5
    # Bottom face is from rows 6 to 8 and columns 3 to 5
    # Left face is from rows 3 to 5 and columns 0 to 2
    # Front face is from rows 3 to 5 and columns 3 to 5
    # Right face is from rows 3 to 5 and columns 6 to 8
    # Back face is from rows 3 to 5 and columns 9 to 11
    if (
        (0 <= row <= 2 and 3 <= col <= 5)
        or (6 <= row <= 8 and 3 <= col <= 5)
        or (3 <= row <= 5 and 0 <= col <= 2)
        or (3 <= row <= 5 and 3 <= col <= 5)
        or (3 <= row <= 5 and 6 <= col <= 8)
        or (3 <= row <= 5 and 9 <= col <= 11)
    ):
        return True
    else:
        return False


def getCellLeftTop(app, row, col):
    # the left x-coordinate and top y-coordinate of a cell
    cellLeft = app.margin + col * app.cellSize
    cellTop = app.margin + row * app.cellSize
    return cellLeft, cellTop


def rotateFrontFaceClockwise(app):
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]

    # rotating the front face 90 degrees clockwise
    for r in range(3):
        for c in range(3):
            app.board[3 + r][3 + c] = frontFace[2 - c][r]

    # the edges that will be replaced
    topEdge = app.board[2][3:6]  # top edge to move to the right
    rightEdge = [
        app.board[3][6],
        app.board[4][6],
        app.board[5][6],
    ]  # right edge to move to the bottom
    bottomEdge = app.board[6][3:6]  # bottom edge to move to the left
    leftEdge = [
        app.board[3][2],
        app.board[4][2],
        app.board[5][2],
    ]  # left edge to move to the top

    
    app.board[2][3:6] = leftEdge[::-1] # the top edge gets the left edge (needs to be reversed)
    for i in range(3):
        app.board[i + 3][6] = topEdge[i] # the right edge gets the top edge (in the same order)
    app.board[6][3:6] = rightEdge[::-1]  # the bottom edge gets the right edge (needs to be reversed)
    for i in range(3):
        app.board[i + 3][2] = bottomEdge[2 - i]  # the left edge gets the bottom edge (in the same order)

    # app.movesLog.append("rotateFrontFaceClockwise")


def rotateFrontFaceAntiClockwise(app):
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]

    # rotating the front face 90 degrees anti-clockwise
    for r in range(3):
        for c in range(3):
            app.board[3 + r][3 + c] = frontFace[c][2 - r]

    # the edges that will be replaced
    topEdge = app.board[2][3:6]  # Top edge to move to the left
    leftEdge = [
        app.board[3][2],
        app.board[4][2],
        app.board[5][2],
    ]  # Left edge to move to the bottom
    bottomEdge = app.board[6][3:6]  # Bottom edge to move to the right
    rightEdge = [
        app.board[3][6],
        app.board[4][6],
        app.board[5][6],
    ]  # Right edge to move to the top

    # rotate the edges anti-clockwise
    
    for i in range(3):
        app.board[i + 3][2] = topEdge[2-i] # the left edge gets the top edge
    app.board[6][3:6] = leftEdge[::-1] # the bottom edge gets the left edge (needs to be reversed)
    for i in range(3):
        app.board[i + 3][6] = bottomEdge[2 - i] # the right edge gets the bottom edge
    app.board[2][3:6] = rightEdge # the top edge gets the right edge (needs to be reversed)

    # app.movesLog.append("rotateFrontFaceAntiClockwise")


def rotateTopFaceClockwise(app):
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    # rotation of the top face 90 degrees clockwise
    newTopFace = [
        [topFace[2][0], topFace[1][0], topFace[0][0]],
        [topFace[2][1], topFace[1][1], topFace[0][1]],
        [topFace[2][2], topFace[1][2], topFace[0][2]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    # the edges that will be replaced
    frontEdge = app.board[3][3:6]
    leftEdge = app.board[3][0:3]
    backEdge = app.board[3][9:12]
    rightEdge = app.board[3][6:9]

    # the pattern front->left->back->right->front
    app.board[3][0:3] = frontEdge # the left edge gets the back edge
    app.board[3][9:12] = leftEdge  # back edge gets the right edge
    app.board[3][6:9] = backEdge  # right edge gets the front edge
    app.board[3][3:6] = rightEdge  # front edge gets the left edge

    # app.movesLog.append("rotateTopFaceClockwise")


def rotateTopFaceAntiClockwise(app):
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    # rotation of the top face 90 degrees anti-clockwise
    newTopFace = [
        [topFace[0][2], topFace[1][2], topFace[2][2]],
        [topFace[0][1], topFace[1][1], topFace[2][1]],
        [topFace[0][0], topFace[1][0], topFace[2][0]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    # edges
    frontEdge = app.board[3][3:6]
    rightEdge = app.board[3][6:9]
    backEdge = app.board[3][9:12]
    leftEdge = app.board[3][0:3]

    # pattern: left->front->right->back->left
    app.board[3][3:6] = leftEdge  # front edge gets the left edge
    app.board[3][6:9] = frontEdge  # right edge gets the front edge
    app.board[3][9:12] = rightEdge  # back edge gets the right edge
    app.board[3][0:3] = backEdge  # left edge gets the back edge

    # app.movesLog.append("rotateTopFaceAntiClockwise")


def rotateRightFaceClockwise(app):
    rightFace = [app.board[r][6:9] for r in range(3, 6)]
    # rotation of the right face 90 degrees clockwise
    newRightFace = [
        [rightFace[2][0], rightFace[1][0], rightFace[0][0]],
        [rightFace[2][1], rightFace[1][1], rightFace[0][1]],
        [rightFace[2][2], rightFace[1][2], rightFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    # the edges that will be replaced
    topEdge = [app.board[0][5], app.board[1][5], app.board[2][5]]
    frontEdge = [app.board[3][5], app.board[4][5], app.board[5][5]]
    backEdge = [app.board[3][9], app.board[4][9], app.board[5][9]]
    bottomEdge = [app.board[6][5], app.board[7][5], app.board[8][5]]

    # rotate the edges
    for i in range(3):
        app.board[i][5] = frontEdge[i]  # top edge gets the front edge
        app.board[i + 3][9] = topEdge[2 - i]  # back edge gets the top edge
        app.board[i + 6][5] = backEdge[2 - i]  # bottom edge gets the back edge
        app.board[i + 3][5] = bottomEdge[i]  # front edge gets the bottom edge

    # app.movesLog.append("rotateRightFaceClockwise")


def rotateRightFaceAntiClockwise(app):
    rightFace = [app.board[r][6:9] for r in range(3, 6)]
    # rotating the right face 90 degrees anti-clockwise
    newRightFace = [
        [rightFace[0][2], rightFace[1][2], rightFace[2][2]],
        [rightFace[0][1], rightFace[1][1], rightFace[2][1]],
        [rightFace[0][0], rightFace[1][0], rightFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    # the edges that will be replaced
    topEdge = [app.board[0][5], app.board[1][5], app.board[2][5]]
    frontEdge = [app.board[3][5], app.board[4][5], app.board[5][5]]
    backEdge = [app.board[3][9], app.board[4][9], app.board[5][9]]
    bottomEdge = [app.board[6][5], app.board[7][5], app.board[8][5]]

    # rotate the edges
    for i in range(3):
        app.board[i + 3][5] = topEdge[i]
        app.board[i][5] = backEdge[2 - i]
        app.board[i + 6][5] = frontEdge[i]
        app.board[i + 3][9] = bottomEdge[2 - i]

    # app.movesLog.append("rotateRightFaceAntiClockwise")


def rotateBottomFaceClockwise(app):
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]
    # rotation of the bottom face 90 degrees clockwise
    newBottomFace = [
        [bottomFace[2][0], bottomFace[1][0], bottomFace[0][0]],
        [bottomFace[2][1], bottomFace[1][1], bottomFace[0][1]],
        [bottomFace[2][2], bottomFace[1][2], bottomFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]

    # the edges
    frontEdge = app.board[5][3:6]
    rightEdge = app.board[5][6:9]
    backEdge = app.board[5][9:12]
    leftEdge = app.board[5][0:3]

    # rotation using the pattern front->right->back->left->front
    app.board[5][6:9] = frontEdge  # right edge gets the front edge
    app.board[5][9:12] = rightEdge  # back edge gets the right edge
    app.board[5][0:3] = backEdge  # left edge gets the back edge
    app.board[5][3:6] = leftEdge  # front edge gets the left edge

    # app.movesLog.append("rotateBottomFaceClockwise")


def rotateBottomFaceAntiClockwise(app):
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]
    # rotating the bottom face 90 degrees anti-clockwise
    newBottomFace = [
        [bottomFace[0][2], bottomFace[1][2], bottomFace[2][2]],
        [bottomFace[0][1], bottomFace[1][1], bottomFace[2][1]],
        [bottomFace[0][0], bottomFace[1][0], bottomFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]

    # the edges that will be replaced
    frontEdge = app.board[5][3:6]
    leftEdge = app.board[5][0:3]
    backEdge = app.board[5][9:12]
    rightEdge = app.board[5][6:9]

    # rotating the edges to their new positions following the pattern left->front->right->back->left
    app.board[5][6:9] = backEdge  # right edge gets the back edge
    app.board[5][3:6] = rightEdge  # front edge gets the right edge
    app.board[5][0:3] = frontEdge  # left edge gets the front edge
    app.board[5][9:12] = leftEdge  # back edge gets the left edge

    # app.movesLog.append("rotatebottomFaceAntiClockwise")


def rotateLeftFaceClockwise(app):
    leftFace = [app.board[r][0:3] for r in range(3, 6)]
    # the rotation of the left face 90 degrees clockwise
    newLeftFace = [
        [leftFace[2][0], leftFace[1][0], leftFace[0][0]],
        [leftFace[2][1], leftFace[1][1], leftFace[0][1]],
        [leftFace[2][2], leftFace[1][2], leftFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]

    # the edges
    frontEdge = [
        app.board[3][3],
        app.board[4][3],
        app.board[5][3],
    ]  # left column of the front face
    bottomEdge = [
        app.board[6][3],
        app.board[7][3],
        app.board[8][3],
    ]  # bottom row of the left side
    backEdge = [
        app.board[3][11],
        app.board[4][11],
        app.board[5][11],
    ]  # left column of the back face (viewed from the front)
    topEdge = [
        app.board[0][3],
        app.board[1][3],
        app.board[2][3],
    ]  # top row of the left side

    # rotate following the pattern front->bottom->back->top->front
    for i in range(3):
        app.board[6 + i][3] = frontEdge[i]  # bottom edge gets the front edge
        app.board[5 - i][11] = bottomEdge[i]  # back edge gets the bottom edge
        app.board[i][3] = backEdge[2 - i]  # top edge gets the back edge
        app.board[3 + i][3] = topEdge[i]  # front edge gets the top edge

    # app.movesLog.append("rotateLeftFaceClockwise")


def rotateLeftFaceAntiClockwise(app):
    leftFace = [app.board[r][0:3] for r in range(3, 6)]
    # rotating the left face 90 degrees anti-clockwise
    newLeftFace = [
        [leftFace[0][2], leftFace[1][2], leftFace[2][2]],
        [leftFace[0][1], leftFace[1][1], leftFace[2][1]],
        [leftFace[0][0], leftFace[1][0], leftFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]

    # the edges
    frontEdge = [app.board[3][3], app.board[4][3], app.board[5][3]]
    topEdge = [app.board[0][3], app.board[1][3], app.board[2][3]]
    backEdge = [app.board[3][11], app.board[4][11], app.board[5][11]]
    bottomEdge = [app.board[6][3], app.board[7][3], app.board[8][3]]

    # rotating following the pattern front->top->back->bottom->front
    for i in range(3):
        app.board[i][3] = frontEdge[i]
        app.board[5 - i][11] = topEdge[i]
        app.board[6 + i][3] = backEdge[2 - i]
        app.board[3 + i][3] = bottomEdge[i]

    # app.movesLog.append("rotateLeftFaceAntiClockwise")


def rotateBackFaceClockwise(app):
    backFace = [app.board[r][9:12] for r in range(3, 6)]
    # rotation of the back face 90 degrees clockwise
    newBackFace = [
        [backFace[2][0], backFace[1][0], backFace[0][0]],
        [backFace[2][1], backFace[1][1], backFace[0][1]],
        [backFace[2][2], backFace[1][2], backFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][9:12] = newBackFace[r]

    # the edges
    topEdge = app.board[0][3:6]
    rightEdge = [app.board[3][8], app.board[4][8], app.board[5][8]]
    bottomEdge = app.board[8][3:6]
    leftEdge = [app.board[3][0], app.board[4][0], app.board[5][0]]

    # rotation following the pattern left->bottom->right->top->left
    app.board[8][3:6] = leftEdge  # bottom edge gets the left edge
    for i in range(3):
        app.board[i + 3][8] = bottomEdge[2 - i]  # right edge gets the bottom edge
    app.board[0][3:6] = rightEdge # top edge gets the right edge (needs to be reversed)
    for i in range(3):
        app.board[i + 3][0] = topEdge[2 - i]  # left edge gets the top edge

    # app.movesLog.append("rotateBackFaceClockwise")


def rotateBackFaceAntiClockwise(app):
    backFace = [app.board[r][9:12] for r in range(3, 6)]
    # rotating the back face 90 degrees anti-clockwise
    newBackFace = [
        [backFace[0][2], backFace[1][2], backFace[2][2]],
        [backFace[0][1], backFace[1][1], backFace[2][1]],
        [backFace[0][0], backFace[1][0], backFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][9:12] = newBackFace[r]

    # the edges
    topEdge = app.board[0][3:6]
    leftEdge = [app.board[3][0], app.board[4][0], app.board[5][0]]
    bottomEdge = app.board[8][3:6]
    rightEdge = [app.board[3][8], app.board[4][8], app.board[5][8]]

    # rotate following the pattern left->bottom->right->top->left
    for i in range(3):
        app.board[i + 3][0] = bottomEdge[i]  # left edge gets the bottom edge
    app.board[8][3:6] = rightEdge[::-1]  # bottom edge gets the right edge
    for i in range(3):
        app.board[i + 3][8] = topEdge[i]  # right edge gets the top edge
    app.board[0][3:6] = leftEdge[::-1]  # top edge gets the left edge

    # app.movesLog.append("rotateBackFaceAntiClockwise")


def rotateEquatorClockwise(app):
    # rotate the equator slice
    #  the edges
    frontEdge = app.board[4][3:6]
    rightEdge = app.board[4][6:9]
    backEdge = app.board[4][9:12]
    leftEdge = app.board[4][0:3]

    # rotating following the pattern front->right->back->left->front
    app.board[4][6:9] = frontEdge  # the right edge gets the front edge
    app.board[4][9:12] = rightEdge  # the back edge gets the right edge
    app.board[4][0:3] = backEdge  # the left edge gets the back edge
    app.board[4][3:6] = leftEdge  # the front edge gets the left edge

    # app.movesLog.append("rotateEquatorFaceClockwise")


def rotateEquatorAntiClockwise(app):
    # rotate the equator slice anti-clockwise
    #  the edges
    frontEdge = app.board[4][3:6]
    rightEdge = app.board[4][6:9]
    backEdge = app.board[4][9:12]
    leftEdge = app.board[4][0:3]

    # rotate following the pattern left->front->right->back->left
    app.board[4][0:3] = frontEdge  # left edge gets the front edge
    app.board[4][3:6] = rightEdge  # front edge gets the right edge
    app.board[4][6:9] = backEdge  # right edge gets the back edge
    app.board[4][9:12] = leftEdge  # back edge gets the left edge

    # app.movesLog.append("rotateEquatorFaceAntiClockwise")


def rotateMiddleClockwise(app):
    # rotate the middle vertical slice
    # the edges
    bottomEdge = [app.board[i][4] for i in range(6, 9)]
    frontEdge = [app.board[i][4] for i in range(3, 6)]
    topEdge = [app.board[i][4] for i in range(0, 3)]
    backEdge = [app.board[i][10] for i in range(3, 6)]

    # move the edges to their new positions following the pattern bottom->front->top->back->bottom
    for i in range(3):
        app.board[i + 3][4] = bottomEdge[i]  # front gets bottom
        app.board[i][4] = frontEdge[i]  # top gets front
        app.board[i + 3][10] = topEdge[2 - i]  # back gets top,
        app.board[8 - i][4] = backEdge[i]  # bottom gets back

    # app.movesLog.append("rotateMiddleFaceClockwise")


def rotateMiddleAntiClockwise(app):  # rotate the middle vertical slice anti-clockwise
    #  the edges
    bottomEdge = [app.board[i][4] for i in range(6, 9)]
    frontEdge = [app.board[i][4] for i in range(3, 6)]
    topEdge = [app.board[i][4] for i in range(0, 3)]
    backEdge = [app.board[i][10] for i in range(3, 6)]

    # rotate following the pattern top->front->bottom->back->top
    for i in range(3):
        app.board[i + 3][4] = topEdge[i]
        app.board[8 - i][4] = frontEdge[2-i]
        app.board[i + 3][10] = bottomEdge[2-i]
        app.board[i][4] = backEdge[2-i]

    # app.movesLog.append("rotateMiddleFaceAntiClockwise")


def scrambleCube(app, numMoves=100):
    moves = {
        rotateFrontFaceClockwise: "F",
        rotateFrontFaceAntiClockwise: "f",
        rotateTopFaceClockwise: "T",
        rotateTopFaceAntiClockwise: "t",
        rotateRightFaceClockwise: "R",
        rotateRightFaceAntiClockwise: "r",
        rotateBottomFaceClockwise: "B",
        rotateBottomFaceAntiClockwise: "b",
        rotateLeftFaceClockwise: "L",
        rotateLeftFaceAntiClockwise: "l",
        rotateBackFaceClockwise: "A",
        rotateBackFaceAntiClockwise: "a",
        rotateMiddleClockwise: "M",
        rotateMiddleAntiClockwise: "m",
        rotateEquatorClockwise: "E",
        rotateEquatorAntiClockwise: "e",
    }

    for i in range(numMoves):
        # select a random move function and execute it
        moveFunction = random.choice(list(moves.keys()))
        moveFunction(app)
        # find the corresponding key
        key = moves[moveFunction]
        app.movesLog.append(key)


def onKeyPress(app, key):
    # print(key)
    if key == "T":
        rotateTopFaceClockwise(app)
    elif key == "t":
        rotateTopFaceAntiClockwise(app)
    elif key == "F":
        rotateFrontFaceClockwise(app)
    elif key == "f":
        rotateFrontFaceAntiClockwise(app)
    elif key == "R":
        rotateRightFaceClockwise(app)
    elif key == "r":
        rotateRightFaceAntiClockwise(app)
    elif key == "L":
        rotateLeftFaceClockwise(app)
    elif key == "l":
        rotateLeftFaceAntiClockwise(app)
    elif key == "B":
        rotateBottomFaceClockwise(app)
    elif key == "b":
        rotateBottomFaceAntiClockwise(app)
    elif key == "A":
        rotateBackFaceClockwise(app)
    elif key == "a":
        rotateBackFaceAntiClockwise(app)
    elif key == "E":
        rotateEquatorClockwise(app)
    elif key == "e":
        rotateEquatorAntiClockwise(app)
    elif key == "M":
        rotateMiddleClockwise(app)
    elif key == "m":
        rotateMiddleAntiClockwise(app)
    elif key == "S" or key == "s":
        scrambleCube(app)
    elif key == "escape":
        onAppStart(app)
    if key != "escape" and (key != "s" and key != "S") and key != 'space':
        app.movesLog.append(key)
    if key == 'space':
        solveCube(app)

def redraw(app):
    drawBackground(app)
    drawBorder(app)
    drawRubiksCube(app)

def printMovesLog(app):
    print(app.movesLog)

def solveCube(app):
    app.solverIndex = len(app.movesLog) - 1  # start from the last move
    app.isSolving = True  # flag to indicate solving is in progress

def onStep(app):
    if app.isSolving:
        if app.solverIndex >= 0:  # there are moves left to solve
            move = app.movesLog[app.solverIndex]
            reverseMove = move.upper() if move.islower() else move.lower()
            print(f"Next move: {reverseMove}")
            onKeyPress(app, reverseMove)  # perform the move
            app.solverIndex -= 1  # move to the next move
        else:
            app.isSolving = False  # solving process is complete
            print("Solving complete.")

# playRubiks()

from cmu_graphics import *
import rubiksCube as rubiks
import levels as levels


def onAppStart(app):
    rubiks.onAppStart(app)
    levels.onAppStart(app)
    app.margin = 70
    app.gameState = False
    app.img = "rubiks.png"


def onKeyPress(app, key):
    rubiks.onKeyPress(app, key)
    rubiks.printMovesLog(app)
    # pass


def redrawAll(app):
    imageWidth, imageHeight = getImageSize(app.img)
    drawRect(0, 0, app.width, app.height, fill="black")
    if app.gameState == False:
        drawImage(app.img, app.width // 4, app.height // 30,
                  width=imageWidth // 3, height=imageHeight // 3)
        welcomeNote = "Welcome to the Rubik's Cube game, here are some features:"
        instruct1 = "* Use uppercases for clockwise rotations"
        instruct1a = "R: RightFace Clockwise Rotation, L: left, B: bottom,"
        instruct1b = "T: top, A: back, F: front, E: equator, M: Middle"
        instruct2 = "* Use lowercase for the anticlokwise rotations, the keys are the same as the above "
        instruct3 = "* Click key 's' to generate a scramble"
        instructions = [welcomeNote, instruct1, instruct1a, instruct1b, instruct2, instruct3]
        y = app.height // 2.5
        for instr in instructions:
            drawLabel(f"{instr}", 50, y, fill="white", font='fantasy',
                      bold=True, size=20, align="left")
            y += 30
        drawRect(app.width // 2 - 20, app.height - 60, 40, 20, fill="white")
        drawLabel("Start", app.width // 2, app.height - 50, fill="black")
    else:
        levels.redrawLevel(app)


def onMousePress(app, mouseX, mouseY):
    if ((app.width // 2 - 20) <= mouseX <= (app.width // 2 + 20)) and (
            (app.height - 60) <= mouseY <= (app.height - 40)):
        app.gameState = True
    levels.onMousePress(app, mouseX, mouseY)


def onStep(app):
    rubiks.onStep(app)


runApp(800, 800)

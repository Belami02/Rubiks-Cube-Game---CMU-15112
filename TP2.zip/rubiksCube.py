from cmu_graphics import *
import random


#################################################
# Term Project: Rubik's cube
#################################################
class Field:
    def __init__(self, x, y, width, height=50, label=None, value=""):
        self.x = x
        self.y = y
        self.width = width
        self.clicked = False
        self.height = height
        self.label = label
        self.value = value

    def draw(self):
        labelOffset = self.width // 2 + 10
        drawLabel(f"{self.label}", self.x - labelOffset,
                  self.y, align="right", font='monospace', bold=True, size=15)
        drawRect(self.x, self.y, self.width, self.height,
                 align="center", fill="white", border="black", borderWidth=2)
        drawLabel(self.value, self.x - self.width // 2 + 5,
                  self.y, align="left", font='monospace', bold=True, size=15)
        if self.clicked:
            borderColor = 'blue'
            drawRect(self.x, self.y, self.width, self.height,
                     align='center', fill=None, border=borderColor, borderWidth=5)

    def onClicked(self, mouseX, mouseY):
        return ((self.x - self.width // 2 <= mouseX <= self.x + self.width // 2)
                and (self.y - self.height // 2 <= mouseY <= self.y + self.height // 2))


class Button:
    def __init__(self, x, y, width, height, label=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.label = label

    def draw(self):
        drawRect(self.x, self.y, self.width, self.height,
                 align="center", fill="lightgray", border="black", borderWidth=2)
        drawLabel(self.label, self.x, self.y, size=15, font='monospace', bold=True)

    def isClicked(self, mouseX, mouseY):
        return (self.x - self.width // 2 <= mouseX <= self.x + self.width // 2) and (
                    self.y - self.height // 2 <= mouseY <= self.y + self.height // 2)


def gameDimensions():
    # each face of the Rubik's cube is 3x3
    faceSize = 3
    cellSize = 30
    marginX = 80
    marginY = 150
    # the cube is spread in a cross pattern with 
    # a maximum width of 4 faces and height of 3
    cols = faceSize * 4
    rows = faceSize * 3
    return rows, cols, cellSize, marginX, marginY


def getFaceStart(faceIndex):
    # mapping assumes the following layout for the unfolded cube:
    #   0
    # 1 2 3 4
    #   5
    # where '0' is the top, '1' is the left,'2' is the front face,
    # '3' is the right, '4' is the back, '5' is the bottom

    if faceIndex == 0:  # Top face
        return 0, 3
    elif faceIndex == 1:  # Left face
        return 3, 0
    elif faceIndex == 2:  # Front face
        return 3, 3
    elif faceIndex == 3:  # Right face
        return 3, 6
    elif faceIndex == 4:  # Back face
        return 3, 9
    elif faceIndex == 5:  # Bottom face
        return 6, 3


def onAppStart(app):
    app.moves = {}
    app.clickedField = None
    app.moves["Moves"] = Field(610, 250, 90, 50, label="Moves")
    app.movesButton = Button(710, 250, 90, 50, label='Execute')
    app.scrambleBtn = Button(300, 640, 90, 50, label="Scramble")
    app.solveCubeBtn = Button(450, 640, 90, 50, label="Solve")
    app.dimension = Button(150, 640, 120, 50, label="Change View")
    app.reset = Button(600, 640, 90, 50, label='Reset')
    app.rows, app.cols, app.cellSize, app.marginX, app.marginY = gameDimensions()
    app.boardWidth = app.cols * app.cellSize
    app.boardHeight = app.rows * app.cellSize
    app.cellBorderWidth = 1
    app.emptyColor = "white"
    app.color = "white"
    app.movesMade = 0
    app.movesClicked = None
    app.image2 = 'rubiks6.png'
    app.image3 = 'rubiks4.png'
    app.score = 0
    app.counter = 0
    app.delay = 25
    app.movesExecutable = []
    app.timerTicks = 0
    app.timerRunning = False
    app.gameDim = False
    app.isSolving = False
    app.movesLog = []  # keep the moves made
    app.initialBoard = [[app.emptyColor for col in range(app.cols)] for row in range(app.rows)]
    app.board = [[app.emptyColor for col in range(app.cols)] for row in range(app.rows)]
    colors = ["white", "orange", "blue", "red", "green", "yellow"]  # colors for each face
    for i in range(6):  # the colors for each face on the board
        faceRow, faceCol = getFaceStart(i)
        for row in range(faceRow, faceRow + 3):
            for col in range(faceCol, faceCol + 3):
                app.board[row][col] = colors[i]
                app.initialBoard[row][col] = colors[i]  # the initial state


def drawBackground(app):
    drawRect(0, 0, app.width, app.height, fill="white")
    imageWidth1, imageHeight1 = getImageSize(app.image2)
    imageWidth2, imageHeight2 = getImageSize(app.image3)
    drawImage(app.image3, 620, 35, width=imageWidth2 // 9, height=imageHeight2 // 9)
    drawImage(app.image2, 700, 25, width=imageWidth1 // 6, height=imageHeight1 // 6)


def drawBorder(app):
    drawRect(app.marginX - 5, app.marginY - 5, app.boardWidth + 10,
             app.boardHeight + 10, fill="black")


def playRubiks():
    rows, cols, cellSize, marginX, marginY = gameDimensions()
    width = cols * cellSize + 2 * marginX
    height = rows * cellSize + 2 * marginY
    runApp(width=width, height=height)


def drawRubiksCube(app):  # the 2d Rubik's cube layout
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)


def drawCell(app, row, col, color=None):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    if color is None:
        color = app.board[row][col]

    if isPartOfFace(app, row, col):
        borderWidth = app.cellBorderWidth
    else:
        borderWidth = 0  # no border if the cell is not part of a face

    drawRect(cellLeft, cellTop, app.cellSize, app.cellSize, fill=color,
             border="black", borderWidth=borderWidth)


def isPartOfFace(app, row, col):
    # Top face is from rows 0 to 2 and columns 3 to 5
    # Bottom face is from rows 6 to 8 and columns 3 to 5
    # Left face is from rows 3 to 5 and columns 0 to 2
    # Front face is from rows 3 to 5 and columns 3 to 5
    # Right face is from rows 3 to 5 and columns 6 to 8
    # Back face is from rows 3 to 5 and columns 9 to 11
    if ((0 <= row <= 2 and 3 <= col <= 5)
            or (6 <= row <= 8 and 3 <= col <= 5)
            or (3 <= row <= 5 and 0 <= col <= 2)
            or (3 <= row <= 5 and 3 <= col <= 5)
            or (3 <= row <= 5 and 6 <= col <= 8)
            or (3 <= row <= 5 and 9 <= col <= 11)):
        return True
    else:
        return False


def getCellLeftTop(app, row, col):
    cellLeft = app.marginX + col * app.cellSize
    cellTop = app.marginY + row * app.cellSize
    return cellLeft, cellTop


def rotateFrontFaceClockwise(app):  # rotating the front face 90 degrees clockwise
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    for r in range(3):
        for c in range(3):
            app.board[3 + r][3 + c] = frontFace[2 - c][r]

    topEdge = app.board[2][3:6]
    rightEdge = [app.board[3][6], app.board[4][6], app.board[5][6]]
    bottomEdge = app.board[6][3:6]
    leftEdge = [app.board[3][2], app.board[4][2], app.board[5][2]]

    # rotations
    app.board[2][3:6] = leftEdge[::-1]
    for i in range(3):
        app.board[i + 3][6] = topEdge[i]
    app.board[6][3:6] = rightEdge[::-1]
    for i in range(3):
        app.board[i + 3][2] = bottomEdge[i]


def rotateFrontFaceAntiClockwise(app):  # rotating the front face 90 degrees anti-clockwise
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    for r in range(3):
        for c in range(3):
            app.board[3 + r][3 + c] = frontFace[c][2 - r]

    topEdge = app.board[2][3:6]
    leftEdge = [app.board[3][2], app.board[4][2], app.board[5][2]]
    bottomEdge = app.board[6][3:6]
    rightEdge = [app.board[3][6], app.board[4][6], app.board[5][6]]

    # rotations
    for i in range(3):
        app.board[i + 3][2] = topEdge[2 - i]
    app.board[6][3:6] = leftEdge
    for i in range(3):
        app.board[i + 3][6] = bottomEdge[2 - i]
    app.board[2][3:6] = rightEdge


def rotateTopFaceClockwise(app):  # rotation of the top face 90 degrees clockwise
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    newTopFace = [
        [topFace[2][0], topFace[1][0], topFace[0][0]],
        [topFace[2][1], topFace[1][1], topFace[0][1]],
        [topFace[2][2], topFace[1][2], topFace[0][2]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    frontEdge = app.board[3][3:6]
    leftEdge = app.board[3][0:3]
    backEdge = app.board[3][9:12]
    rightEdge = app.board[3][6:9]

    # rotations
    app.board[3][0:3] = frontEdge
    app.board[3][9:12] = leftEdge
    app.board[3][6:9] = backEdge
    app.board[3][3:6] = rightEdge


def rotateTopFaceAntiClockwise(app):  # rotation of the top face 90 degrees anti-clockwise
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    newTopFace = [
        [topFace[0][2], topFace[1][2], topFace[2][2]],
        [topFace[0][1], topFace[1][1], topFace[2][1]],
        [topFace[0][0], topFace[1][0], topFace[2][0]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    frontEdge = app.board[3][3:6]
    rightEdge = app.board[3][6:9]
    backEdge = app.board[3][9:12]
    leftEdge = app.board[3][0:3]

    # rotations
    app.board[3][3:6] = leftEdge
    app.board[3][6:9] = frontEdge
    app.board[3][9:12] = rightEdge
    app.board[3][0:3] = backEdge


def rotateRightFaceClockwise(app):  # rotation of the right face 90 degrees clockwise
    rightFace = [app.board[r][6:9] for r in range(3, 6)]
    newRightFace = [
        [rightFace[2][0], rightFace[1][0], rightFace[0][0]],
        [rightFace[2][1], rightFace[1][1], rightFace[0][1]],
        [rightFace[2][2], rightFace[1][2], rightFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    topEdge = [app.board[0][5], app.board[1][5], app.board[2][5]]
    frontEdge = [app.board[3][5], app.board[4][5], app.board[5][5]]
    backEdge = [app.board[3][9], app.board[4][9], app.board[5][9]]
    bottomEdge = [app.board[6][5], app.board[7][5], app.board[8][5]]

    # rotate the edges
    for i in range(3):
        app.board[i][5] = frontEdge[i]
        app.board[i + 3][9] = topEdge[2 - i]
        app.board[i + 6][5] = backEdge[2 - i]
        app.board[i + 3][5] = bottomEdge[i]


def rotateRightFaceAntiClockwise(app):  # rotating the right face 90 degrees anti-clockwise
    rightFace = [app.board[r][6:9] for r in range(3, 6)]
    newRightFace = [
        [rightFace[0][2], rightFace[1][2], rightFace[2][2]],
        [rightFace[0][1], rightFace[1][1], rightFace[2][1]],
        [rightFace[0][0], rightFace[1][0], rightFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    # the edges that will be replaced
    topEdge = [app.board[0][5], app.board[1][5], app.board[2][5]]
    frontEdge = [app.board[3][5], app.board[4][5], app.board[5][5]]
    backEdge = [app.board[3][9], app.board[4][9], app.board[5][9]]
    bottomEdge = [app.board[6][5], app.board[7][5], app.board[8][5]]

    # rotate the edges
    for i in range(3):
        app.board[i + 3][5] = topEdge[i]
        app.board[i][5] = backEdge[2 - i]
        app.board[i + 6][5] = frontEdge[i]
        app.board[i + 3][9] = bottomEdge[2 - i]


def rotateBottomFaceClockwise(app):  # rotation of the bottom face 90 degrees clockwise
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]

    newBottomFace = [
        [bottomFace[2][0], bottomFace[1][0], bottomFace[0][0]],
        [bottomFace[2][1], bottomFace[1][1], bottomFace[0][1]],
        [bottomFace[2][2], bottomFace[1][2], bottomFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]

    # the edges
    frontEdge = app.board[5][3:6]
    rightEdge = app.board[5][6:9]
    backEdge = app.board[5][9:12]
    leftEdge = app.board[5][0:3]

    # rotation 
    app.board[5][6:9] = frontEdge
    app.board[5][9:12] = rightEdge
    app.board[5][0:3] = backEdge
    app.board[5][3:6] = leftEdge


def rotateBottomFaceAntiClockwise(app):  # rotating the bottom face 90 degrees anti-clockwise
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]

    newBottomFace = [
        [bottomFace[0][2], bottomFace[1][2], bottomFace[2][2]],
        [bottomFace[0][1], bottomFace[1][1], bottomFace[2][1]],
        [bottomFace[0][0], bottomFace[1][0], bottomFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]

    # the edges that will be replaced
    frontEdge = app.board[5][3:6]
    leftEdge = app.board[5][0:3]
    backEdge = app.board[5][9:12]
    rightEdge = app.board[5][6:9]

    # rotating the edges 
    app.board[5][6:9] = backEdge
    app.board[5][3:6] = rightEdge
    app.board[5][0:3] = frontEdge
    app.board[5][9:12] = leftEdge


def rotateLeftFaceClockwise(app):
    leftFace = [app.board[r][0:3] for r in range(3, 6)]

    newLeftFace = [
        [leftFace[2][0], leftFace[1][0], leftFace[0][0]],
        [leftFace[2][1], leftFace[1][1], leftFace[0][1]],
        [leftFace[2][2], leftFace[1][2], leftFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]

    # the edges
    frontEdge = [app.board[3][3], app.board[4][3], app.board[5][3]]
    bottomEdge = [app.board[6][3], app.board[7][3], app.board[8][3]]
    backEdge = [app.board[3][11], app.board[4][11], app.board[5][11]]
    topEdge = [app.board[0][3], app.board[1][3], app.board[2][3]]

    # rotations
    for i in range(3):
        app.board[6 + i][3] = frontEdge[i]
        app.board[3 + i][11] = bottomEdge[2 - i]
        app.board[i][3] = backEdge[2 - i]
        app.board[3 + i][3] = topEdge[i]


def rotateLeftFaceAntiClockwise(app):  # rotating the left face 90 degrees anti-clockwise
    leftFace = [app.board[r][0:3] for r in range(3, 6)]

    newLeftFace = [
        [leftFace[0][2], leftFace[1][2], leftFace[2][2]],
        [leftFace[0][1], leftFace[1][1], leftFace[2][1]],
        [leftFace[0][0], leftFace[1][0], leftFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]

    # the edges
    frontEdge = [app.board[3][3], app.board[4][3], app.board[5][3]]
    topEdge = [app.board[0][3], app.board[1][3], app.board[2][3]]
    backEdge = [app.board[3][11], app.board[4][11], app.board[5][11]]
    bottomEdge = [app.board[6][3], app.board[7][3], app.board[8][3]]

    # rotation
    for i in range(3):
        app.board[i][3] = frontEdge[i]
        app.board[3 + i][11] = topEdge[2 - i]
        app.board[6 + i][3] = backEdge[2 - i]
        app.board[3 + i][3] = bottomEdge[i]


def rotateBackFaceClockwise(app):  # rotation of the back face 90 degrees clockwise
    backFace = [app.board[r][9:12] for r in range(3, 6)]

    newBackFace = [
        [backFace[2][0], backFace[1][0], backFace[0][0]],
        [backFace[2][1], backFace[1][1], backFace[0][1]],
        [backFace[2][2], backFace[1][2], backFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][9:12] = newBackFace[r]

    # the edges
    topEdge = app.board[0][3:6]
    rightEdge = [app.board[3][8], app.board[4][8], app.board[5][8]]
    bottomEdge = app.board[8][3:6]
    leftEdge = [app.board[3][0], app.board[4][0], app.board[5][0]]

    # rotation 
    app.board[8][3:6] = leftEdge
    for i in range(3):
        app.board[i + 3][8] = bottomEdge[2 - i]
    app.board[0][3:6] = rightEdge
    for i in range(3):
        app.board[i + 3][0] = topEdge[2 - i]


def rotateBackFaceAntiClockwise(app):  # rotating the back face 90 degrees anti-clockwise
    backFace = [app.board[r][9:12] for r in range(3, 6)]

    newBackFace = [
        [backFace[0][2], backFace[1][2], backFace[2][2]],
        [backFace[0][1], backFace[1][1], backFace[2][1]],
        [backFace[0][0], backFace[1][0], backFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][9:12] = newBackFace[r]

    # the edges
    topEdge = app.board[0][3:6]
    leftEdge = [app.board[3][0], app.board[4][0], app.board[5][0]]
    bottomEdge = app.board[8][3:6]
    rightEdge = [app.board[3][8], app.board[4][8], app.board[5][8]]

    # rotations
    for i in range(3):
        app.board[i + 3][0] = bottomEdge[i]
    app.board[8][3:6] = rightEdge[::-1]
    for i in range(3):
        app.board[i + 3][8] = topEdge[i]
    app.board[0][3:6] = leftEdge[::-1]


def rotateEquatorClockwise(app):  # rotate the equator slice
    frontEdge = app.board[4][3:6]
    rightEdge = app.board[4][6:9]
    backEdge = app.board[4][9:12]
    leftEdge = app.board[4][0:3]

    # rotation
    app.board[4][6:9] = frontEdge
    app.board[4][9:12] = rightEdge
    app.board[4][0:3] = backEdge
    app.board[4][3:6] = leftEdge


def rotateEquatorAntiClockwise(app):  # rotate the equator slice anti-clockwise
    frontEdge = app.board[4][3:6]
    rightEdge = app.board[4][6:9]
    backEdge = app.board[4][9:12]
    leftEdge = app.board[4][0:3]

    # rotations
    app.board[4][0:3] = frontEdge
    app.board[4][3:6] = rightEdge
    app.board[4][6:9] = backEdge
    app.board[4][9:12] = leftEdge


def rotateMiddleClockwise(app):  # rotate the middle vertical slice
    bottomEdge = [app.board[i][4] for i in range(6, 9)]
    frontEdge = [app.board[i][4] for i in range(3, 6)]
    topEdge = [app.board[i][4] for i in range(0, 3)]
    backEdge = [app.board[i][10] for i in range(3, 6)]

    # rotations
    for i in range(3):
        app.board[i + 3][4] = bottomEdge[i]
        app.board[i][4] = frontEdge[i]
        app.board[i + 3][10] = topEdge[2 - i]
        app.board[6 + i][4] = backEdge[2 - i]


def rotateMiddleAntiClockwise(app):  # rotate the middle vertical slice anti-clockwise
    bottomEdge = [app.board[i][4] for i in range(6, 9)]
    frontEdge = [app.board[i][4] for i in range(3, 6)]
    topEdge = [app.board[i][4] for i in range(0, 3)]
    backEdge = [app.board[i][10] for i in range(3, 6)]

    # rotation
    for i in range(3):
        app.board[i + 3][4] = topEdge[i]
        app.board[6 + i][4] = frontEdge[i]
        app.board[i + 3][10] = bottomEdge[2 - i]
        app.board[i][4] = backEdge[2 - i]


def rotateCubeClockwise(app):  # rotate the cube clockwise
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    rightFace = [[app.board[r][c] for c in range(6, 9)] for r in range(3, 6)]
    backFace = [[app.board[r][c] for c in range(9, 12)] for r in range(3, 6)]
    leftFace = [[app.board[r][c] for c in range(0, 3)] for r in range(3, 6)]
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]

    # rotate side faces
    for r in range(3):
        for c in range(3):
            app.board[r + 3][c + 6] = frontFace[r][c]  # Front to Right
            app.board[r + 3][c + 9] = rightFace[r][c]  # Right to Back
            app.board[r + 3][c] = backFace[r][c]  # Back to Left
            app.board[r + 3][c + 3] = leftFace[r][c]  # Left to Front

    # rotate top and bottom faces
    newTopFace = [
        [topFace[0][2], topFace[1][2], topFace[2][2]],
        [topFace[0][1], topFace[1][1], topFace[2][1]],
        [topFace[0][0], topFace[1][0], topFace[2][0]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    newBottomFace = [
        [bottomFace[2][0], bottomFace[1][0], bottomFace[0][0]],
        [bottomFace[2][1], bottomFace[1][1], bottomFace[0][1]],
        [bottomFace[2][2], bottomFace[1][2], bottomFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]


def rotateCubeAntiClockwise(app):  # rotate cube anticlockwise
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    rightFace = [[app.board[r][c] for c in range(6, 9)] for r in range(3, 6)]
    backFace = [[app.board[r][c] for c in range(9, 12)] for r in range(3, 6)]
    leftFace = [[app.board[r][c] for c in range(0, 3)] for r in range(3, 6)]
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]

    # rotate side faces
    for r in range(3):
        for c in range(3):
            app.board[r + 3][c + 3] = rightFace[r][c]  # Right to Front
            app.board[r + 3][c] = frontFace[r][c]  # Front to Left
            app.board[r + 3][c + 9] = leftFace[r][c]  # Left to Back
            app.board[r + 3][c + 6] = backFace[r][c]  # Back to Right

    # rotate top and bottom faces
    newTopFace = [
        [topFace[2][0], topFace[1][0], topFace[0][0]],
        [topFace[2][1], topFace[1][1], topFace[0][1]],
        [topFace[2][2], topFace[1][2], topFace[0][2]],
    ]
    for r in range(3):
        app.board[r][3:6] = newTopFace[r]

    newBottomFace = [
        [bottomFace[0][2], bottomFace[1][2], bottomFace[2][2]],
        [bottomFace[0][1], bottomFace[1][1], bottomFace[2][1]],
        [bottomFace[0][0], bottomFace[1][0], bottomFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 6][3:6] = newBottomFace[r]


def rotateCubeUp(app):  # rotate cube up
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    backFace = [[app.board[r][c] for c in range(9, 12)] for r in range(3, 6)]
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]
    rightFace = [[app.board[r][c] for c in range(6, 9)] for r in range(3, 6)]
    leftFace = [[app.board[r][c] for c in range(0, 3)] for r in range(3, 6)]

    # rotate the cube up by shifting the faces
    for r in range(3):
        for c in range(3):
            app.board[r + 3][c + 9] = topFace[r][c]  # Top to Back
            app.board[r + 6][c + 3] = backFace[2 - r][c]  # Back to Bottom
            app.board[r + 3][c + 3] = bottomFace[r][c]  # Bottom to Front
            app.board[r][c + 3] = frontFace[r][c]  # Front to Top

    # rotate right and left faces
    newRightFace = [
        [rightFace[2][0], rightFace[1][0], rightFace[0][0]],
        [rightFace[2][1], rightFace[1][1], rightFace[0][1]],
        [rightFace[2][2], rightFace[1][2], rightFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    newLeftFace = [
        [leftFace[0][2], leftFace[1][2], leftFace[2][2]],
        [leftFace[0][1], leftFace[1][1], leftFace[2][1]],
        [leftFace[0][0], leftFace[1][0], leftFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]


def rotateCubeDown(app):  # rotating the cube down
    frontFace = [[app.board[r][c] for c in range(3, 6)] for r in range(3, 6)]
    topFace = [app.board[r][3:6] for r in range(0, 3)]
    backFace = [[app.board[r][c] for c in range(9, 12)] for r in range(3, 6)]
    bottomFace = [app.board[r][3:6] for r in range(6, 9)]
    rightFace = [[app.board[r][c] for c in range(6, 9)] for r in range(3, 6)]
    leftFace = [[app.board[r][c] for c in range(0, 3)] for r in range(3, 6)]

    # rotate the cube down by shifting the faces
    for r in range(3):
        for c in range(3):
            app.board[r + 6][c + 3] = frontFace[r][c]  # Front to Bottom
            app.board[r + 3][c + 9] = bottomFace[r][c]  # Bottom to Back
            app.board[r][c + 3] = backFace[r][c]  # Back to Top
            app.board[r + 3][c + 3] = topFace[2 - r][c]  # Top to Front

    # rotate right and left faces
    newRightFace = [
        [rightFace[0][2], rightFace[1][2], rightFace[2][2]],
        [rightFace[0][1], rightFace[1][1], rightFace[2][1]],
        [rightFace[0][0], rightFace[1][0], rightFace[2][0]],
    ]
    for r in range(3):
        app.board[r + 3][6:9] = newRightFace[r]

    newLeftFace = [
        [leftFace[2][0], leftFace[1][0], leftFace[0][0]],
        [leftFace[2][1], leftFace[1][1], leftFace[0][1]],
        [leftFace[2][2], leftFace[1][2], leftFace[0][2]],
    ]
    for r in range(3):
        app.board[r + 3][0:3] = newLeftFace[r]


def drawIsometricCube(app):  # the isometric view of the cube
    # Bottom Face 
    startX, startY = 230, 355
    horizOffset = 30
    vertOffset = 20
    for row in range(3):
        for col in range(3):
            topX = startX + (col - row) * horizOffset
            topY = startY + (row + col) * vertOffset
            drawPolygon(topX, topY, topX + horizOffset, topY + vertOffset,
                        topX, topY + 2 * vertOffset, topX - horizOffset,
                        topY + vertOffset, fill=app.board[8 - row][col + 3],
                        opacity=20, border='black')

    for startX, startY, stepY in [(70, 210, -20), (300, 150, +20)]:
        for i in range(3):
            for j in range(3):
                topX = startX + i * 30
                topY = startY + j * 40
                if startX == 70:  # Left Face 
                    drawPolygon(topX, topY, topX + 30, topY - 20, topX + 30,
                                topY + 20, topX, topY + 40, fill=app.board[j + 3][2 - i],
                                opacity=20, border="black")

                else:  # Back Face
                    drawPolygon(topX, topY, topX + 30, topY + 20, topX + 30, topY + 60,
                                topX, topY + 40, fill=app.board[j + 3][11 - i], opacity=20, border="black")
            startY += stepY

    # Top Face
    startX, startY = 230, 145
    horizOffset = 30
    vertOffset = 20
    for row in range(3):
        for col in range(3):
            topX = startX + (col - row) * horizOffset
            topY = startY + (row + col) * vertOffset

            drawPolygon(topX, topY, topX + horizOffset, topY + vertOffset,
                        topX, topY + 2 * vertOffset, topX - horizOffset,
                        topY + vertOffset, fill=app.board[row][col + 3], border='black')

    for startX, startY, stepY in [(140, 205, 20), (230, 265, -20)]:
        for i in range(3):
            for j in range(3):
                topX = startX + i * 30
                topY = startY + j * 40

                if startX == 140:  # Front Face
                    drawPolygon(topX, topY, topX + 30, topY + 20, topX + 30,
                                topY + 60, topX, topY + 40, fill=app.board[j + 3][i + 3],
                                border="black")

                else:  # Right Face
                    drawPolygon(topX, topY, topX + 30, topY - 20, topX + 30,
                                topY + 20, topX, topY + 40, fill=app.board[j + 3][i + 6],
                                border="black")
            startY += stepY


def scrambleCube(app, numMoves):
    moves = {
        rotateFrontFaceClockwise: "F",
        rotateFrontFaceAntiClockwise: "f",
        rotateTopFaceClockwise: "T",
        rotateTopFaceAntiClockwise: "t",
        rotateRightFaceClockwise: "R",
        rotateRightFaceAntiClockwise: "r",
        rotateBottomFaceClockwise: "B",
        rotateBottomFaceAntiClockwise: "b",
        rotateLeftFaceClockwise: "L",
        rotateLeftFaceAntiClockwise: "l",
        rotateBackFaceClockwise: "A",
        rotateBackFaceAntiClockwise: "a",
        rotateMiddleClockwise: "M",
        rotateMiddleAntiClockwise: "m",
        rotateEquatorClockwise: "E",
        rotateEquatorAntiClockwise: "e",
    }

    for i in range(numMoves):
        # select a random move function and execute it
        moveFunction = random.choice(list(moves.keys()))
        moveFunction(app)
        # find the corresponding key
        key = moves[moveFunction]
        app.movesLog.append(key)

    app.movesMade = 0
    app.timerTicks = 0
    app.timerRunning = True


def checkIfSolved(app):
    for row in range(app.rows):
        for col in range(app.cols):
            if app.board[row][col] != app.initialBoard[row][col]:
                return False
    app.timerRunning = False
    # print(f"Time taken to solve: ...")  # print the time taken, still working on it
    return True

def printMovesLog(app):
    print(app.movesLog)


def solveCube(app):
    app.solverIndex = len(app.movesLog) - 1
    app.isSolving = True


def onMousePress(app, mouseX, mouseY):
    if app.scrambleBtn.isClicked(mouseX, mouseY):
        scrambleCube(app, 20)

    elif app.reset.isClicked(mouseX, mouseY):
        onAppStart(app)

    elif app.movesButton.isClicked(mouseX, mouseY):
        executeMove(app, app.movesClicked.value)
        app.movesClicked.value = ''

    elif app.solveCubeBtn.isClicked(mouseX, mouseY):
        solveCube(app)

    elif app.dimension.isClicked(mouseX, mouseY):
        app.gameDim = not app.gameDim

    for field in app.moves:
        if app.moves[field].onClicked(mouseX, mouseY):
            app.moves[field].clicked = True
            app.movesClicked = app.moves[field]
        else:
            app.moves[field].clicked = False


def executeMove(app, s):
    movesList = list(s)
    moveDict = {'F': rotateFrontFaceClockwise,
                'f': rotateFrontFaceAntiClockwise,
                'T': rotateTopFaceClockwise,
                't': rotateTopFaceAntiClockwise,
                'R': rotateRightFaceClockwise,
                'r': rotateRightFaceAntiClockwise,
                'L': rotateLeftFaceClockwise,
                'l': rotateLeftFaceAntiClockwise,
                'B': rotateBottomFaceClockwise,
                'b': rotateBottomFaceAntiClockwise,
                'A': rotateBackFaceClockwise,
                'a': rotateBackFaceAntiClockwise,
                'M': rotateMiddleClockwise,
                'm': rotateMiddleAntiClockwise,
                'E': rotateEquatorClockwise,
                'e': rotateEquatorAntiClockwise}

    for char in movesList:
        if char in moveDict:
            app.movesExecutable.append(moveDict[char])


def redraw(app):
    drawBackground(app)
    formatTime(app)
    for field in app.moves:
        app.moves[field].draw()
    app.movesButton.draw()
    app.scrambleBtn.draw()
    app.solveCubeBtn.draw()
    app.reset.draw()
    app.dimension.draw()

    if app.gameDim:
        # draw the isometric cube (3D view)
        drawIsometricCube(app)
    else:
        # draw the regular Rubik's cube (2D view)
        drawBorder(app)
        drawRubiksCube(app)


def onKeyPress(app, key):
    if (app.moves['Moves'].clicked
            == False):
        if key == "T":
            rotateTopFaceClockwise(app)
        elif key == "t":
            rotateTopFaceAntiClockwise(app)
        elif key == "F":
            rotateFrontFaceClockwise(app)
        elif key == "f":
            rotateFrontFaceAntiClockwise(app)
        elif key == "R":
            rotateRightFaceClockwise(app)
        elif key == "r":
            rotateRightFaceAntiClockwise(app)
        elif key == "L":
            rotateLeftFaceClockwise(app)
        elif key == "l":
            rotateLeftFaceAntiClockwise(app)
        elif key == "B":
            rotateBottomFaceClockwise(app)
        elif key == "b":
            rotateBottomFaceAntiClockwise(app)
        elif key == "A":
            rotateBackFaceClockwise(app)
        elif key == "a":
            rotateBackFaceAntiClockwise(app)
        elif key == "E":
            rotateEquatorClockwise(app)
        elif key == "e":
            rotateEquatorAntiClockwise(app)
        elif key == "M":
            rotateMiddleClockwise(app)
        elif key == "m":
            rotateMiddleAntiClockwise(app)
    elif key == "S" or key == "s":
        scrambleCube(app, 20)
    elif key == "escape":
        onAppStart(app)
    elif key == "right":
        rotateCubeClockwise(app)
    elif key == "left":
        rotateCubeAntiClockwise(app)
    elif key == "up":
        rotateCubeUp(app)
    elif key == "down":
        rotateCubeDown(app)
    if key in ['F', 'f', 'R', 'r', 'T', 't', 'L', 'l',
               'E', 'e', 'B', 'b', 'A', 'a', 'M', 'm']:
        app.movesMade += 1
        app.movesLog.append(key)
    if key == 'space':
        solveCube(app)
    if isinstance(app.movesClicked, Field):
        if len(key) == 1 and key in ['F', 'f', 'R', 'r', 'T', 't', 'L', 'l',
                                     'E', 'e', 'B', 'b', 'A', 'a', 'M', 'm']:
            app.movesClicked.value += key


def formatTime(app):
    seconds = app.timerTicks // 10  # 10 times per second
    minutes = seconds // 60
    seconds = seconds % 60
    drawLabel(f"TIME: {minutes:02d}:{seconds:02d}", 100, 50,
              font='monospace', size=20, bold=True)


def onStep(app):
    app.counter += 1
    if app.counter >= app.delay:
        if len(app.movesExecutable) > 0:
            move = app.movesExecutable.pop(0)
            move(app)
            app.counter = 0
    if app.isSolving:
        if app.solverIndex >= 0:  # there are moves left to solve
            move = app.movesLog[app.solverIndex]
            reverseMove = move.upper() if move.islower() else move.lower()
            print(f"Next move: {reverseMove}")
            onKeyPress(app, reverseMove)  # perform the move
            app.solverIndex -= 1  # move to the next move
        else:
            app.isSolving = False  # solving process is complete
            app.movesLog = []
            print("Solving complete.")

    if checkIfSolved(app):
        app.state = "solved"

    if app.timerRunning:
        app.timerTicks += 1

